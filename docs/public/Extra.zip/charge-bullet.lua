---蓄力射击

ExtraPlayer = Class(player_class)
local charge_bullet = lstg.CreateGameObjectClass()

--[[
考虑蓄力计数器的以下状态变化:
1. 若火力过低 (<1P), 则计数归零 (counter=0), 否则继续
2. 若松开射击键, 则计数归零 (counter=0), 否则继续
3. 若处于低速, 则计数增加 (counter++)
4. 若处于高速, 则进入发弹逻辑, 然后计数归零 (counter=0):
    (1) 若蓄力到一定程度 (counter > __), 则发弹
    (2) 否则, 不会发弹
5. 若处于低速, 但蓄力时间过长 (counter > __), 则发弹, 然后计数归零
]]

function ExtraPlayer:init()
    player_class.init(self)
    self.imgs = {}
    for i = 1, 24 do self.imgs[i] = 'white' end

    self.charge_counter = 0    -- 蓄力计数器
    self.min_charge_time = 20  -- 最小蓄力时间
    self.max_charge_time = 180 -- 最大蓄力时间
end

function ExtraPlayer:frame()
    player_class.frame(self)
    -- 状态转移条件
    local has_enough_power = int(lstg.var.power / 100) > 0
    local is_shooting = self.fire > 0.9
    local is_slow = self.slow == 1
    -- 状态转移逻辑
    if not has_enough_power or not is_shooting then
        self.charge_counter = 0
    else
        if is_slow then
            self.charge_counter = self.charge_counter + 1
        end
        if not is_slow or self.charge_counter >= self.max_charge_time then
            if self.charge_counter >= self.min_charge_time then
                charge_bullet.create(self.x, self.y,
                    int(lstg.var.power / 100), self.charge_counter)
            end
            self.charge_counter = 0
        end
    end
end

---随便写个诱导
function charge_bullet.create(x, y, power, counter)
    local self = New(charge_bullet)
    player_bullet_trail.init(self, 'leaf', x, y, 6, 90, nil, 900,
        0.5 * counter * (1 + (power - 1) / 3)) -- 瞎写的伤害计算公式
    self.v = 8
    local scale = counter / 100 + 1
    self.a, self.b = 12 * scale, 12 * scale
    self.hscale, self.vscale = scale, scale
end

function charge_bullet:frame()
    player_class.findtarget(self)
    player_bullet_trail.frame(self)
end

function ExtraPlayer:render()
    player_class.render(self)
    RenderTTF2('sc_name', self.charge_counter, 0, 0, 0, 0, 1, Color(0xffffffff), 'center')
end

lstg.plugin.RegisterEvent("afterMod", "My Players", 100, function()
    Include("reimu-player/player.lua")
end)

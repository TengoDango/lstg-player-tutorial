lstg.plugin.RegisterEvent("afterTHlib", "Reimu2P", 99, function()
    Include("reimu-player/player.lua")
end)

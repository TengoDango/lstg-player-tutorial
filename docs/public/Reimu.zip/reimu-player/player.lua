-- 自机类
ReimuPlayer = Class(player_class)
-- 添加自机类到自机列表
AddPlayerToPlayerList("Hakurei Reimu 2P", "ReimuPlayer", "Reimu")

-- 前置
local img = "reimu-player:"
local tex = "reimu-player:"
local dir = "reimu-player/"
local lib = {}

----------------------------------------------------------------

-- 初始化回调
function ReimuPlayer:init()
    player_class.init(self)
    lib.load_resources()

    -- 高低速
    self.hspeed, self.lspeed = 4, 2
    -- 判定大小
    self.A, self.B = 0.5, 0.5
    -- 行走图
    self.imgs = {}
    for i = 1, 24 do
        self.imgs[i] = img .. "player" .. i
    end

    -- 子机位置
    self.slist = {
        {
            -- 0P 火力的子机位置
        },
        {
            -- 1P 火力的子机位置
            -- { 高速x, 高速y, 低速x, 低速y }
            { 0, 36, 0, 24 },
        },
        {
            -- 2P 火力的子机位置
            { -32, 0, -12, 24 },
            { 32,  0, 12,  24 },
        },
        {
            -- 3P 火力的子机位置
            { -32, -8,  -16, 20 },
            { 0,   -32, 0,   28 },
            { 32,  -8,  16,  20 },
        },
        {
            -- 4P 火力的子机位置
            { -36, -12, -16, 20 },
            { -16, -32, -6,  28 },
            { 16,  -32, 6,   28 },
            { 36,  -12, 16,  20 },
        },
    }
    self.slist[6] = self.slist[5]

    -- 自定义变量
    self.anglelist = {
        { 90,  90,  90, 90 },
        { 90,  90,  90, 90 },
        { 100, 80,  90, 90 },
        { 100, 90,  80, 90 },
        { 110, 100, 80, 70 },
    }
end

----------------------------------------------------------------

-- 导入图片等资源
function lib.load_resources()
    LoadTexture(tex .. "reimu", dir .. "reimu.png")
    -- 行走图
    LoadImageGroup(img .. "player", tex .. "reimu", 0, 0, 32, 48, 8, 3)
    -- 主炮子弹
    LoadImage(img .. "bullet-main", tex .. "reimu", 192, 160, 64, 16, 16, 16)
    SetImageState(img .. "bullet-main", "", Color(160, 255, 255, 255))
    SetImageCenter(img .. "bullet-main", 56, 8)
    -- 主炮子弹消弹特效
    LoadAnimation(img .. "bullet-main-eff", tex .. "reimu", 0, 144, 16, 16, 4, 1, 4)
    SetAnimationState(img .. "bullet-main-eff", "mul+add", Color(160, 255, 255, 255))
    -- 子机诱导弹 (hspeed)
    LoadImage(img .. "bullet-trail", tex .. "reimu", 64, 160, 16, 16, 16, 16)
    SetImageState(img .. "bullet-trail", "", Color(128, 255, 255, 255))
    -- 诱导弹消弹特效
    LoadAnimation(img .. "bullet-trail-eff", tex .. "reimu", 64, 160, 16, 16, 4, 1, 4)
    SetAnimationState(img .. "bullet-trail-eff", "mul+add", Color(160, 255, 255, 255))
    -- 子机直线弹 (lspeed)
    LoadImage(img .. "bullet-lspeed", tex .. "reimu", 64, 176, 64, 16, 64, 16)
    SetImageState(img .. "bullet-lspeed", "", Color(128, 255, 255, 255))
    -- 子机直线弹消弹特效
    CopyImage(img .. "bullet-lspeed-eff1", img .. "bullet-lspeed")
    LoadAniFromFile(img .. "bullet-lspeed-eff2", dir .. "lspeed-eff.png", false, 1, 9, 1)
    SetAnimationCenter(img .. "bullet-lspeed-eff2", 0, 8)
    SetAnimationState(img .. "bullet-lspeed-eff2", "mul+add", Color(255, 128, 0, 255))
    -- 子机
    LoadImage(img .. "support", tex .. "reimu", 64, 144, 16, 16)
    -- 高速 bomb
    CopyImage(img .. "spell-ball", "parimg1")
    LoadImageFromFile(img .. "bomb-eff", dir .. "bomb-eff.png")
    -- 低速 bomb 结界
    LoadImageFromFile(img .. "kekkai", dir .. "kekkai.png")
    SetImageState(img .. "kekkai", "mul+add", Color(128, 64, 64, 255))
end

----------------------------------------------------------------

-- 渲染回调
function ReimuPlayer:render()
    -- 子机的渲染
    for i = 1, 4 do
        if self.sp[i] and self.sp[i][3] > 0.5 then
            Render(
                img .. "support",              -- 贴图
                self.supportx + self.sp[i][1], -- x
                self.supporty + self.sp[i][2], -- y
                self.timer * 3                 -- 朝向
            )
        end
    end
    -- 行走图的渲染 (默认的渲染行为)
    player_class.render(self)
end

----------------------------------------------------------------

-- 通常射击
function ReimuPlayer:shoot()
    self.nextshoot = 4
    lstg.PlaySound("plst00", 0.3)
    -- 主炮子弹
    lib.bullet_main.create(self.x + 10, self.y, 2)
    lib.bullet_main.create(self.x - 10, self.y, 2)
    -- 子机子弹
    for i = 1, 4 do
        if self.sp[i] and self.sp[i][3] > 0.5 then
            if self.slow == 1 then
                -- 低速: 直线弹
                lib.bullet_lspeed.create(
                    self.supportx + self.sp[i][1] - 3,
                    self.supporty + self.sp[i][2],
                    0.3
                )
                lib.bullet_lspeed.create(
                    self.supportx + self.sp[i][1] + 3,
                    self.supporty + self.sp[i][2],
                    0.3
                )
            else
                -- 高速: 诱导弹
                if self.timer % 8 < 4 then
                    -- 0~4P --> 1~5
                    local power = int(lstg.var.power / 100) + 1
                    lib.bullet_trail.create(
                        self.supportx + self.sp[i][1],
                        self.supporty + self.sp[i][2],
                        self.anglelist[power][i],
                        900, 0.7
                    )
                end
            end
        end
    end
end

----------------------------------------------------------------

-- 主炮子弹
lib.bullet_main = lstg.CreateGameObjectClass()

function lib.bullet_main.create(x, y, dmg)
    -- 创建实例
    local self = New(lib.bullet_main)

    -- 设置实例的属性
    -- player_bullet_straight.init(self, img .. "bullet-main", x, y, 24, 90, dmg)
    self.group = GROUP_PLAYER_BULLET
    self.layer = LAYER_PLAYER_BULLET
    self.img = img .. "bullet-main"
    self.x, self.y = x, y
    self.rot = 90
    self.vy = 24
    self.dmg = dmg
    -- self.a, self.b = 16, 16

    -- 返回实例
    return self
end

-- kill 回调
function lib.bullet_main:kill()
    -- 实例被 kill 时触发该回调
    lib.bullet_main.create_eff(self.x, self.y)
end

-- 主炮消弹特效
lib.bullet_main_eff = lstg.CreateGameObjectClass()

function lib.bullet_main.create_eff(x, y)
    local self = New(lib.bullet_main_eff)
    -- 注意一下碰撞组和图层
    self.group = GROUP_GHOST
    self.layer = LAYER_PLAYER_BULLET + 50
    -- img 为动画资源时会自动循环播放
    self.img = img .. "bullet-main-eff"
    self.x, self.y = x, y
    self.rot = 90
    self.vy = 2.25
    return self
end

-- 帧逻辑回调
function lib.bullet_main_eff:frame()
    -- 共4张图, 每4帧换下一张图, 共16帧
    -- timer 计数器从0开始, 0~15 共16帧, 动画播放一轮
    if self.timer == 15 then Del(self) end
end

----------------------------------------------------------------

-- 低速子机的直线弹
lib.bullet_lspeed = lstg.CreateGameObjectClass()

function lib.bullet_lspeed.create(x, y, dmg)
    local self = New(lib.bullet_lspeed)
    player_bullet_straight.init(self, img .. "bullet-lspeed", x, y, 24, 90, dmg)
    return self
end

function lib.bullet_lspeed:kill()
    lib.bullet_lspeed.create_eff1(self.x, self.y, self.rot + ran:Float(-15, 15))
    lib.bullet_lspeed.create_eff2(self.x, self.y)
end

-- 消弹特效 1
lib.bullet_lspeed_eff1 = lstg.CreateGameObjectClass()

function lib.bullet_lspeed.create_eff1(x, y, rot)
    local self = New(lib.bullet_lspeed_eff1)
    self.group = GROUP_GHOST
    self.layer = LAYER_PLAYER_BULLET + 50
    self.img = img .. "bullet-lspeed-eff1"
    self.x, self.y = x, y + 32
    self.rot = rot
    self.vy = 2
    self.hscale = ran:Float(1, 1.2)
    return self
end

function lib.bullet_lspeed_eff1:frame()
    if self.timer == 15 then Del(self) end
end

function lib.bullet_lspeed_eff1:render()
    -- 让不透明度逐渐从 255 减到 0
    local a = 255 * (1 - self.timer / 16)
    -- SetImageState(self.img, "mul+add", Color(a, 255, 255, 255))
    SetImgState(self, "mul+add", a, 255, 255, 255)
    DefaultRenderFunc(self)
end

--- test: _object from editor
local bullet_lspeed_eff1 = Class(_object)
function bullet_lspeed_eff1.create(x, y, rot)
    local self = New(lib.bullet_lspeed_eff1)
    self.group = GROUP_GHOST
    self.layer = LAYER_PLAYER_BULLET + 50
    self.img = img .. "bullet-lspeed-eff1"
    self.x, self.y = x, y + 32
    self.rot = rot
    self.vy = 2
    self.hscale = ran:Float(1, 1.2)
    task.New(self, function()
        local a = 255
        for _ = 1, 16 do
            a = a - 255 / (16 - 1)
            self._a = a
            task.Wait(1)
        end
        RawDel(self)
    end)
    -- 防止报错
    self.hp = 10
    self._blend, self._a, self._r, self._g, self._b = "mul+add", 255, 255, 255, 255
    self._servants = {}
    return self
end

-- 消弹特效 2
lib.bullet_lspeed_eff2 = lstg.CreateGameObjectClass()

function lib.bullet_lspeed.create_eff2(x, y)
    local self = New(lib.bullet_lspeed_eff2)
    self.group = GROUP_GHOST
    self.layer = LAYER_PLAYER_BULLET + 50
    self.img = img .. "bullet-lspeed-eff2"
    self.x, self.y = x, y + 32
    self.rot = -90 + ran:Float(-10, 10)
    self.hscale = ran:Float(1.5, 1.8)
    self.vscale = 1.5
end

function lib.bullet_lspeed_eff2:frame()
    -- 动画一共9张图, 每帧切换下一张, 共9帧
    if self.timer == 9 - 1 then Del(self) end
end

----------------------------------------------------------------

-- 诱导弹
lib.bullet_trail = lstg.CreateGameObjectClass()

function lib.bullet_trail.create(x, y, rot, trail, dmg)
    local self = New(lib.bullet_trail)
    player_bullet_trail.init(self, img .. "bullet-trail", x, y, 8, rot, nil, trail, dmg)
    return self
end

function lib.bullet_trail:frame()
    player_class.findtarget(self)
    player_bullet_trail.frame(self)
end

function lib.bullet_trail:kill()
    lib.bullet_trail.create_eff(self.x, self.y, self.rot)
end

-- 诱导弹消弹特效
lib.bullet_trail_eff = lstg.CreateGameObjectClass()

function lib.bullet_trail.create_eff(x, y, rot)
    local self = New(lib.bullet_trail_eff)
    self.group = GROUP_GHOST
    self.layer = LAYER_PLAYER_BULLET + 50
    self.img = img .. "bullet-trail-eff"
    self.x, self.y = x, y
    SetV(self, 1, rot, true)
end

function lib.bullet_trail_eff:frame()
    if self.timer == 15 then Del(self) end
end

----------------------------------------------------------------

-- Bomb 对应回调
function ReimuPlayer:spell()
    -- 调整收集线
    self.collect_line = self.collect_line - 500
    New(tasker, function()
        task.Wait(90)
        self.collect_line = self.collect_line + 500
    end)

    if self.slow == 1 then
        -- 低速 bomb
        self.nextspell = 240 -- 冷却时间
        self.protect = 360   -- 无敌时间
        lstg.PlaySound("power1", 0.8)
        lstg.PlaySound("cat00", 0.8)
        misc.ShakeScreen(210, 3) -- 震屏
        -- 遮罩
        New(player_spell_mask, 64, 64, 255, 30, 210, 30)
        -- 结界的整体判定和渲染
        lib.kekkai.create(self.x, self.y)
    else
        -- 高速 bomb
        self.nextspell = 300
        self.protect = 360
        lstg.PlaySound("nep00", 0.8)
        lstg.PlaySound("slash", 0.8)
        New(player_spell_mask, 128, 0, 255, 30, 180, 30)
        -- 梦想封印
        local a0 = ran:Int(0, 360)
        for i = 1, 8 do
            lib.spell_ball.create(self.x, self.y, a0, i)
        end
    end
end

----------------------------------------------------------------

-- 低速 bomb: 结界
lib.kekkai = lstg.CreateGameObjectClass()

function lib.kekkai.create(x, y)
    local self = New(lib.kekkai)

    -- 属性设置
    self.group = GROUP_PLAYER_BULLET
    self.layer = LAYER_PLAYER_BULLET
    self.img = img .. "kekkai"
    self.x, self.y = x, y

    self.a, self.b = 0, 0
    self.dmg = 1.25
    -- 将 killflag 设为 true 会使得子弹与敌机碰撞后不会被删除
    -- 同时也会使子弹的伤害变为帧伤, 调控伤害时需要注意
    self.killflag = true

    local dr = 12
    local n = 20
    local t = 12

    -- 自定义变量
    self._a = 128
    self.list, self.n = {}, 0
    -- dr / 256 是因为图片资源的长宽为 256 像素
    self.r, self.dr, self.dscale = 0, dr, dr / 256

    -- Task
    task.New(self, function()
        -- 创建各层结界的信息
        for i = 1, n do
            self.list[i] = { scale = 0, rot = 0 }
            self.n = i
            task.Wait(t)
        end
        -- 状态更新
        self.dmg = 0
        lstg.PlaySound("slash", 1)
        -- 淡出
        for i = 128, 0, -4 do
            self._a = i
            task.Wait(1)
        end
        Del(self)
    end)
end

function lib.kekkai:frame()
    -- 使得 task 可以正常执行
    task.Do(self)
    -- 控制每6帧播放击中音效
    self.mute = (self.timer % 6 ~= 0)
    -- 扩大判定范围
    self.r = self.r + self.dr
    self.a, self.b = self.r, self.r
    -- 结界信息更新
    local omega = 1
    for i = 1, self.n do
        self.list[i].scale = self.list[i].scale + self.dscale
        self.list[i].rot = self.list[i].rot + omega
        omega = omega * -1
    end
    -- 消除子弹的对象, 只会存在一帧所以可以每帧创建
    New(bomb_bullet_killer, self.x, self.y, self.a, self.b)
end

function lib.kekkai:render()
    SetImgState(self, "mul+add", self._a, 64, 64, 255)
    for i = 1, self.n do
        -- 渲染各层结界
        Render(self.img, self.x, self.y, self.list[i].rot, self.list[i].scale)
    end
end

----------------------------------------------------------------

-- 高速 bomb: 阴阳玉
lib.spell_ball = lstg.CreateGameObjectClass()

function lib.spell_ball.create(x, y, angle0, index)
    local self = New(lib.spell_ball)
    self.group = GROUP_PLAYER_BULLET
    self.layer = LAYER_PLAYER_BULLET
    -- self.hide = true -- 渲染由其他对象进行
    self.x, self.y = x, y
    self.bound = false
    self.rot = angle0 + 45 * index
    self.scale = 1
    -- 诱导弹参数
    self.v = 10
    self.trail = 1200

    task.New(self, function()
        -- 第一阶段: 围绕自机
        self.dmg = 1
        self.killflag = true
        local omega = math.deg(self.v / 190)
        for i = 1, 190 - 10 * index do
            self.rot = self.rot - omega
            local r = i * 1
            self.x = r * cos(self.rot + 90) + player.x
            self.y = r * sin(self.rot + 90) + player.y
            task.Wait(1)
        end
        -- 第二阶段: 诱导弹
        self.dmg = 35
        self.killflag = false
        while self.timer <= 230 do
            player_class.findtarget(self)
            player_bullet_trail.frame(self)
            task.Wait(1)
        end
        -- 第三阶段: 爆炸收尾
        self.dmg = 0.4
        self.killflag = true
        for i = 1, 10 do
            self.scale = i * 0.5 + 1
            task.Wait(1)
        end
        Kill(self)
    end)
end

function lib.spell_ball:frame()
    -- 贴图大小和判定大小设置
    local s = self.scale
    self.hscale, self.vscale = s, s
    self.a, self.b = s * 30, s * 30
    -- 防止出界
    if self.x > 192 then
        self.x = 192
        self.vx, self.vy = 0, 0
    end
    if self.x < -192 then
        self.x = -192
        self.vx, self.vy = 0, 0
    end
    if self.y > 224 then
        self.y = 224
        self.vx, self.vy = 0, 0
    end
    if self.y < -224 then
        self.y = -224
        self.vx, self.vy = 0, 0
    end
    -- 让 task 生效
    task.Do(self)
    -- 与敌机子弹的碰撞
    New(bomb_bullet_killer, self.x, self.y, self.a, self.b)
    -- 复刻粒子效果
    lib.spell_ball.create_particle(self)
end

function lib.spell_ball:kill()
    misc.ShakeScreen(5, 5)
    lstg.PlaySound("explode", 0.3)
    -- 逐渐扩大的圈
    New(
        bubble, "parimg12", self.x, self.y, 30, 4, 6,
        Color(255, 255, 255, 255), Color(0, 255, 255, 255),
        LAYER_ENEMY_BULLET_EF, ""
    )
    -- 散射的粒子
    local a = ran:Float(0, 360)
    for i = 1, 12 do
        lib.spell_ball.create_eff(self.x, self.y, ran:Float(4, 6), a + i * 30)
    end
end

-- 模拟阴阳玉的粒子渲染
-- 算是拖影的一种实现方式
lib.spell_ball.particle = lstg.CreateGameObjectClass()

function lib.spell_ball.create_particle(master)
    local self = New(lib.spell_ball.particle)
    self.layer = master.layer + 0.1
    self.colli = false
    self.img = img .. "spell-ball"
    self.x, self.y = master.x, master.y
    -- 自定义变量
    self.master = master
    self._blend = "mul+add"
    self._a = 255
    self._r = ran:Int(0, 255)
    self._g = ran:Int(0, 255)
    self._b = ran:Int(0, 255)
    return self
end

function lib.spell_ball.particle:frame()
    if self.timer == 24 or not IsValid(self.master) then
        Del(self)
        return -- 不再执行之后的内容, 防止因 master 无效而报错
    end
    local t = self.timer / 24
    local scale = (1 - t * 0.6) * 3
    self.hscale = self.master.hscale * scale
    self.vscale = self.master.vscale * scale
    self._a = (1 - t) * 255
end

function lib.spell_ball.particle:render()
    SetImgState(self, self._blend, self._a, self._r, self._g, self._b)
    DefaultRenderFunc(self)
end

-- 消弹散射特效
lib.spell_ball.eff = lstg.CreateGameObjectClass()

function lib.spell_ball.create_eff(x, y, v, rot)
    local self = New(lib.spell_ball.eff)
    self.group = GROUP_GHOST
    self.layer = LAYER_PLAYER_BULLET
    self.img = img .. "bomb-eff"
    self.x, self.y = x, y
    SetV(self, v, rot, true)
    self.scale = 2
    self.hscale, self.vscale = self.scale, self.scale
    local colors = { { 255, 0, 0 }, { 0, 255, 0 }, { 0, 0, 255 } }
    self.color = colors[ran:Int(1, 3)]
    return self
end

function lib.spell_ball.eff:frame()
    self.hscale = self.scale * (1 - self.timer / 60)
    self.vscale = self.scale * (1 - self.timer / 60)
    if self.timer == 30 then Del(self) end
end

function lib.spell_ball.eff:render()
    SetImgState(self, "mul+add", 255 * (1 - self.timer / 30), self.color[1], self.color[2], self.color[3])
    DefaultRenderFunc(self)
end

TestPlayer = Class(player_class)
AddPlayerToPlayerList("test player", "TestPlayer", "test")

function TestPlayer:init()
    player_class.init(self)
    self.imgs = {}
    for i = 1, 24 do
        self.imgs[i] = "white"
    end
end
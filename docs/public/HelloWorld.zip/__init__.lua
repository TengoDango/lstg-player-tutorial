lstg.plugin.RegisterEvent("afterTHlib", "Hello world", 100, function()
    Include("test-player/player.lua")
end)

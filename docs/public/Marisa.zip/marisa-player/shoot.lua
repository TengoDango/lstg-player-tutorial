---通常射击

local img = 'marisa-player:'

----------------------------------------------------------------
---主炮, 标准套餐

local main_bullet = lstg.CreateGameObjectClass()
local main_bullet_eff = lstg.CreateGameObjectClass()

function main_bullet.create(class, x, y)
    local self = New(class)
    self.group = GROUP_PLAYER_BULLET
    self.layer = LAYER_PLAYER_BULLET
    self.img = img .. 'bullet'
    self.x, self.y = x, y
    self.vy, self.rot = 24, 90
    self.a, self.b = 16, 16
    self.dmg = 2
    return self
end

function main_bullet:kill()
    main_bullet_eff:create(self.x, self.y)
end

function main_bullet_eff.create(class, x, y)
    local self = New(class)
    self.layer = LAYER_PLAYER_BULLET + 50
    self.img = img .. 'bullet-eff'
    self.x, self.y = x, y
    self.vy, self.rot = 2, 90
    return self
end

function main_bullet_eff:frame()
    if self.timer == 15 then Del(self) end
end

----------------------------------------------------------------
---子机导弹

local missile = lstg.CreateGameObjectClass()
local missile_eff = lstg.CreateGameObjectClass()

function missile.create(class, x, y)
    local self = New(class)
    self.group = GROUP_PLAYER_BULLET
    self.layer = LAYER_PLAYER_BULLET
    self.img = img .. 'missile'
    self.x, self.y = x, y
    self.rot = 90
    self.a, self.b = 16, 16
    self.dmg = 1.4
    return self
end

function missile:frame()
    -- 初速度3, 末速度12, 匀加速度1/3
    self.vy = min(12, 3 + self.timer / 3)
end

function missile:kill()
    lstg.PlaySound('msl2', 0.3)
    missile_eff:create(
        self.x + ran:Float(-6, 6),
        self.y + ran:Float(-6, 6),
        4)
end

function missile_eff.create(class, x, y, counter)
    local self = New(class)
    self.group = GROUP_PLAYER_BULLET
    self.layer = LAYER_PLAYER_BULLET
    self.img = img .. 'missile-eff'
    self.x, self.y = x, y
    self.a, self.b = 8, 8

    self.dmg = 0.1
    self.killflag = true
    self.mute = true

    self.counter = counter
    return self
end

function missile_eff:frame()
    if self.timer == 3 and self.counter > 0 then
        -- 递归生成若干次爆炸特效
        -- counter: 4 -> 3 -> 2 -> 1 -/> 0
        missile_eff:create(
            self.x + ran:Float(8, 16) * ran:Sign(),
            self.y + ran:Float(8, 16) * ran:Sign(),
            self.counter - 1)
    end
    if self.timer == 7 then Del(self) end
end

----------------------------------------------------------------

---导弹信息的初始化
function Marisa2P:InitMissiles()
    self.missile_counter = 0
    -- 每次发射导弹的子机编号
    local list = {
        -- 0P, 1P, 2P
        { { 1, 2, 3, 4 }, {}, {},       {} },
        -- 3P
        { { 1, 3 },       {}, { 2 },    {} },
        -- 4P
        { { 1, 4 },       {}, { 2, 3 }, {} },
    }
    self.missile_list = { list[1], list[1], list[1], list[2], list[3] }
end

table.insert(Marisa2P.init_events, Marisa2P.InitMissiles)

---射击回调
function Marisa2P:shoot()
    self.nextshoot = 4
    lstg.PlaySound('plst00', 0.15)
    main_bullet:create(self.x + 6, self.y)
    main_bullet:create(self.x - 6, self.y)

    if self.slow == 1 then
        local sp = self.spinfo
        local indexes = self.missile_list
            [int(sp.power) + 1]
            [self.missile_counter % 4 + 1]
        for _, i in ipairs(indexes) do
            if sp.valid[i] > 0.5 then
                missile:create(sp.x[i], sp.y[i])
            end
        end
        self.missile_counter = self.missile_counter + 1
    end
end

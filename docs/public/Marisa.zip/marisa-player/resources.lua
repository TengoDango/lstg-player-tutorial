---资源加载

local img = 'marisa-player:'           -- 资源名统一前缀
local assets = 'marisa-player/assets/' -- 资源文件夹

local function load_img(name)
    LoadImageFromFile(img .. name, assets .. name .. '.png', false)
end

local function load_img_group(name, cols, rows)
    LoadImageGroupFromFile(img .. name, assets .. name .. '.png', false, cols, rows)
end

local function load_ani(name, cols, rows, interval)
    LoadAniFromFile(img .. name, assets .. name .. '.png', false, cols, rows, interval)
end

local function set_img_state(name, blend, a, r, g, b)
    SetImageState(img .. name, blend, Color(
        a or 255, r or 255, g or 255, b or 255))
end

local function set_ani_state(name, blend, a, r, g, b)
    SetAnimationState(img .. name, blend, Color(
        a or 255, r or 255, g or 255, b or 255))
end

---资源加载
function Marisa2P:LoadResources()
    -- 自机 & 子机
    load_img_group('walk-image', 8, 3)
    load_img_group('support', 13, 1)
    -- 主炮子弹
    load_img('bullet')
    set_img_state('bullet', '', 128)
    load_ani('bullet-eff', 4, 1, 4)
    set_ani_state('bullet-eff', '', 128)
    -- 导弹
    load_img('missile')
    set_img_state('missile', '', 240)
    load_ani('missile-eff', 4, 1, 2)
    set_ani_state('missile-eff', 'mul+add', 128)
    -- 激光
    load_img('laser')
    load_ani('laser-eff', 4, 1, 4)
    load_img('laser-star')
    set_img_state('laser-star', 'mul+add')
    -- 魔炮
    load_img('spark')
    load_img('spark-wave')

    load_img('star')

    -- 更改图片中心点, 简化魔炮渲染
    SetImageCenter(img .. 'spark', 0, 64)
    -- 更改纹理的采样方式, 简化激光渲染
    SetTextureSamplerState(img .. 'laser', "linear+wrap")
end

table.insert(Marisa2P.init_events, Marisa2P.LoadResources)

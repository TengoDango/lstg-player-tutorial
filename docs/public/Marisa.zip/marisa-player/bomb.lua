---高速雷 & 低速雷

local img = 'marisa-player:'

----------------------------------------------------------------
---data自带组件包装

---符卡遮罩
local function create_spell_mask(red, green, blue, t1, t2, t3)
    return New(player_spell_mask, red, green, blue, t1, t2, t3)
end

---扩大的消弹圈
local function create_bullet_killer(x, y)
    return New(bullet_killer, x, y)
end

---维持一帧的消弹圈
local function create_bomb_bullet_killer(x, y, a, b)
    return New(bomb_bullet_killer, x, y, a, b)
end

----------------------------------------------------------------
---星尘幻想

-- 星星发射器
local emitter = lstg.CreateGameObjectClass()
-- 单个星星
local star = lstg.CreateGameObjectClass()

function emitter.create(class, duration)
    local self = New(class)
    self.hide = true
    self.rot, self.omiga = 90, 1.5
    self.duration = duration
    return self
end

function emitter:frame()
    if self.timer == self.duration - 1 then
        Del(self); return
    end
    local particles = 8
    local spread = 25
    for i = 1, 3 do
        local a = self.rot + 120 * i
        for _ = 1, particles do
            star:create(player.x, player.y,
                ran:Float(10, 14),
                ran:Float(a - spread, a + spread),
                ran:Float(4, 8),
                Color(255,
                    ran:Int(0, 255),
                    ran:Int(0, 255),
                    ran:Int(0, 255)),
                0.1)
        end
    end
end

function star.create(class, x, y, v, angle, omiga, color, dmg)
    local self = New(class)
    self.group = GROUP_PLAYER_BULLET
    self.layer = LAYER_PLAYER_BULLET + 0.1
    self.img = img .. 'star'
    self.x, self.y = x, y
    self.omiga = omiga
    SetV(self, v, angle)
    self.hscale, self.vscale = 1.5, 1.5
    self.a, self.b = 16, 16
    self.colli = false
    self.dmg = dmg
    self.killflag = true
    self.color = color
    return self
end

function star:frame()
    if self.timer == 2 then self.colli = true end
end

function star:render()
    SetImageState(self.img, 'mul+add', self.color)
    DefaultRenderFunc(self)
end

----------------------------------------------------------------
---魔炮

-- 魔炮主体, 仅渲染
local spark = lstg.CreateGameObjectClass()
-- 冲击波, 有碰撞伤害
local wave = lstg.CreateGameObjectClass()

function spark.create(class, duration)
    local self = New(class)
    self.layer = LAYER_PLAYER_BULLET
    self.img = img .. 'spark'
    self.rot = 90

    self.duration = duration
    self.enable_wave = false
    -- 用自定义的长宽属性控制自带属性
    self.length, self.width = 0, 0

    local stretch_time = 20
    local turn_on_time = 25
    local turn_off_time = 25
    task.New(self, function()
        -- 第一步: 伸长
        self.width = 4
        for i = 1, stretch_time do
            self.length = 640 * i / stretch_time
            task.Wait(1)
        end
        misc.ShakeScreen(270, 5)
        -- 第二步: 展开
        self.enable_wave = true
        for i = 1, turn_on_time do
            self.width = 4 + 156 * i / turn_on_time
            task.Wait(1)
        end
        -- 第三步: 等待
        task.Wait(duration - stretch_time - turn_on_time - turn_off_time)
        -- 第四步: 折叠
        for i = turn_off_time, 1, -1 do
            self.width = 160 * i / turn_off_time
            task.Wait(1)
        end
        Del(self)
    end)
    return self
end

function spark:frame()
    task.Do(self)
    self.x, self.y = player.x, player.y
    self.hscale = self.length / 256
    self.vscale = self.width / 64
    if self.enable_wave and self.timer % 8 == 0 then
        wave:create(self)
    end
end

function spark:render()
    local ang = self.width / 60
    SetImgState(self, 'mul+add', 255, 255, 0, 0)
    Render(self.img, self.x, self.y, self.rot + ang, self.hscale, self.vscale)
    SetImgState(self, 'mul+add', 255, 0, 255, 0)
    Render(self.img, self.x, self.y, self.rot, self.hscale, self.vscale)
    SetImgState(self, 'mul+add', 255, 0, 0, 255)
    Render(self.img, self.x, self.y, self.rot - ang, self.hscale, self.vscale)
end

function wave.create(class, master)
    local self = New(class)
    self.group = GROUP_PLAYER_BULLET
    self.layer = LAYER_PLAYER_BULLET
    self.img = img .. 'spark-wave'
    self.rot = 90
    self.rect = true
    self.dmg = 1.3
    self.killflag = true

    self.master = master
    self.rel = 20  -- 相对坐标
    self.relV = 20 -- rel 的变化率
    return self
end

function wave:frame()
    if not IsValid(self.master) then
        Del(self); return
    end

    self.x = self.master.x
    self.y = self.master.y + self.rel
    self.rel = self.rel + self.relV

    local t = self.timer / 12
    local scale = min(1, sqrt(t)) * 0.6
    self.hscale = scale * self.master.hscale
    self.vscale = scale * self.master.vscale
    self.a = 80 * self.hscale
    self.b = 128 * self.vscale

    local killer = create_bomb_bullet_killer(
        self.x, self.y, self.a, self.b)
    killer.rot = 90
end

function wave:render()
    local a = min(self.timer / 6, 1)
    SetImgState(self, 'mul+add', 128 * a, 255, 255, 255)
    DefaultRenderFunc(self)
end

----------------------------------------------------------------

function Marisa2P:spell()
    self.collect_line = self.collect_line - 500
    New(tasker, function()
        task.Wait(90)
        self.collect_line = self.collect_line + 500
    end)
    if self.slow == 0 then
        -- 高速雷: 星尘幻想
        local duration = 240
        self.nextspell = duration
        self.nextshoot = duration -- bomb 结束前禁止射击
        self.protect = 360
        lstg.PlaySound('slash', 1)
        lstg.PlaySound('nep00', 1)
        misc.ShakeScreen(210, 3)
        create_spell_mask(0, 0, 255, 30, 210, 30)
        emitter:create(duration)
        New(tasker, function()
            create_bullet_killer(self.x, self.y)
            task.Wait(duration)
            lstg.PlaySound('slash', 1)
            create_bullet_killer(self.x, self.y)
        end)
    else
        -- 低速雷: 魔炮
        local duration = 300
        self.nextspell = duration
        self.nextshoot = duration
        self.protect = 360
        lstg.PlaySound('slash', 1)
        lstg.PlaySound('nep00', 1)
        -- misc.ShakeScreen(270, 5) -- 移到魔炮 obj 里了
        create_spell_mask(255, 255, 0, 30, 240, 30)
        spark:create(duration)
        New(tasker, function()
            self.slowlock = true -- 强制低速
            create_bullet_killer(self.x, self.y)
            task.Wait(duration)
            lstg.PlaySound('slash', 1)
            self.slowlock = false
            create_bullet_killer(self.x, self.y)
        end)
    end
end

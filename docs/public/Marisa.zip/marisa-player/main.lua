---自机类整体定义

Marisa2P = Class(player_class)
AddPlayerToPlayerList('Kirisame Marisa 2P', 'Marisa2P', 'Marisa')

local img = 'marisa-player:'

-- 一个简陋的事件系统
Marisa2P.init_events = {}
Marisa2P.frame_events = {}
Marisa2P.render_events = {}

function Marisa2P:init()
    player_class.init(self)

    for _, event in ipairs(Marisa2P.init_events) do
        event(self)
    end

    self.hspeed, self.lspeed = 5, 2
    self.A, self.B = 1, 1
    self.imgs = {}
    for i = 1, 24 do
        self.imgs[i] = img .. 'walk-image' .. i
    end
end

function Marisa2P:frame()
    player_class.frame(self)
    for _, event in ipairs(Marisa2P.frame_events) do
        event(self)
    end
end

function Marisa2P:render()
    player_class.render(self)
    for _, event in ipairs(Marisa2P.render_events) do
        event(self)
    end
end

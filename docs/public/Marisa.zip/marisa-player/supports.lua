---虽然没有必要, 但是演示一下手写子机系统

local img = 'marisa-player:'

---子机信息初始化
function Marisa2P:InitSupports()
    -- (自定义属性) 记录所有子机信息
    self.spinfo = {
        -- 数组部分类似sp表, 每帧更新
        -- { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 },

        -- 类似slist表
        list = {
            {},
            {
                -- 高速x, 高速y, 高速朝向 (给激光用的),
                -- 低速x, 低速y, 低速朝向 (低速没有激光所以干脆全设为90)
                { 0, 32, 90, 0, 29, 90 },
            },
            {
                { -30, 10, 95, -8, 23, 90 },
                { 30,  10, 85, 8,  23, 90 },
            },
            {
                { -30, 0,  95, -10, 24, 90 },
                { 0,   32, 90, 0,   32, 90 },
                { 30,  0,  85, 10,  24, 90 },
            },
            {
                { -30, 10, 95, -15,  20, 90 },
                { -12, 32, 90, -7.5, 29, 90 },
                { 12,  32, 90, 7.5,  29, 90 },
                { 30,  10, 85, 15,   20, 90 },
            },
        },
        -- 平滑跟随火力等级 (0~4P)
        power = int(lstg.var.power / 100),
        -- 最大子机数量
        num = 4,
        -- 子机有效性 (0~1)
        valid = {},
        -- 子机实际位置
        x = {},
        y = {},
        -- 激光实际朝向
        rot = {},
    }
    -- 补全剩余数据
    Marisa2P.UpdateSupports(self)
end

table.insert(Marisa2P.init_events, Marisa2P.InitSupports)

---更新子机系统
function Marisa2P:UpdateSupports()
    local sp = self.spinfo

    -- 1. 火力等级更新

    local power = int(lstg.var.power / 100)
    if sp.power > power then
        sp.power = sp.power - 0.05
    elseif sp.power < power then
        sp.power = sp.power + 0.05
    end
    if abs(sp.power - power) < 0.05 then
        sp.power = power
    end

    -- 2. 子机sp表更新

    if not self.time_stop then
        local s = int(sp.power) + 1
        local t = sp.power - int(sp.power)
        for i = 1, sp.num do
            local valid0 = sp.list[s][i]
            -- 考虑到4P情况, 需要先判断sp.list[s+1]是否存在
            local valid1 = sp.list[s + 1] and sp.list[s + 1][i]

            if valid0 and valid1 then
                sp[i] = MixTable(t,
                    MixTable(self.lh, sp.list[s][i]),
                    MixTable(self.lh, sp.list[s + 1][i]))
                sp.valid[i] = 1
            elseif valid0 and not valid1 then
                -- 由于子机随火力增加不会减少, 该分支实际上不会触发
                sp[i] = MixTable(self.lh, sp.list[s][i])
                sp.valid[i] = 1 - t
            elseif not valid0 and valid1 then
                sp[i] = MixTable(self.lh, sp.list[s + 1][i])
                sp.valid[i] = t
            else
                -- 此时sp[i]可能不存在, 使用时需要判断
                sp.valid[i] = 0
            end
        end
    end

    -- 3. 子机实际位置更新

    for i = 1, sp.num do
        if sp[i] then
            sp.x[i] = self.supportx + sp[i][1]
            sp.y[i] = self.supporty + sp[i][2]
            sp.rot[i] = sp[i][3]
        end
    end
end

table.insert(Marisa2P.frame_events, Marisa2P.UpdateSupports)

---渲染子机
function Marisa2P:RenderSupports()
    local sp = self.spinfo
    for i = 1, sp.num do
        if sp[i] then
            -- SetImageState('white', '', Color(0xffffffff) * sp.valid[i])
            -- Render('white', sp.x[i], sp.y[i], sp.rot[i], 10, 0.1)
            Render(img .. 'support1', sp.x[i], sp.y[i], 0, sp.valid[i], 1)
        end
    end
end

table.insert(Marisa2P.render_events, Marisa2P.RenderSupports)

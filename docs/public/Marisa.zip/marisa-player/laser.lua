---高速射击: 激光

local img = 'marisa-player:'

local function polar(r, angle)
    return r * cos(angle), r * sin(angle)
end

local laser = lstg.CreateGameObjectClass()

---自机初始化时生成激光, 之后不会删除激光
table.insert(Marisa2P.init_events, function(self)
    for i = 1, 4 do laser:create(self, i) end
end)

function laser.create(class, player, idx)
    local self = New(class)
    self.group = GROUP_SPELL
    self.layer = LAYER_PLAYER + 1
    self.rect = true
    self.bound = false
    self.killflag = true
    self.player = player
    self.idx = idx

    -- 渲染设置
    self.tex = img .. 'laser'
    self.texlen, self.texwid = GetTextureSize(self.tex)
    self.offset = 0 -- 激光纹理偏移量
    self.len = 0    -- 渲染长度
    self.tmplen = 0 -- 临时变量, 用于计算渲染长度
    self.valid = 0  -- 激光有效性

    -- 位置设置
    self.rx, self.ry = 0, 0 -- 根节点坐标
    self.maxlen = 640       -- 判定长度, 也是最大渲染长度

    -- 碰撞
    self.a, self.b = self.maxlen / 2, self.texwid / 2
    self.is_hit = false -- 当前是否发生碰撞
    self.target = nil   -- 当前碰撞目标
    self.eff_scale = 0  -- 击中特效大小
    self.dmg = 0        -- 当前伤害
    self.DMG = 0.25     -- 默认伤害

    return self
end

---由 根节点(rx,ry) 长度(len) 朝向(rot) 纹理偏移量(offset) 渲染激光
function laser:render()
    if self.valid == 0 then return end -- 删掉这行也可以

    local x, y = self.rx, self.ry
    local rot = self.rot
    local texwid = self.texwid
    local offset = self.offset

    -- 激光宽度引起的渲染坐标偏移
    local widX, widY = polar(texwid / 2, rot + 90)

    local color = self.is_hit
        and Color(self.valid * 128, 255, 64, 64)
        or Color(self.valid * 128, 255, 255, 255)

    -- 由于激光纹理的采样 (SetTextureSamplerState) 使用了 wrap
    -- 超出纹理的位置会对纹理大小取余, 形成无缝平铺效果
    -- 这使得渲染位置的计算相对简单
    local lenX, lenY = polar(self.len, rot)
    RenderTexture(self.tex, 'mul+add',
        { x + widX, y + widY, 0.5, offset, 0, color },
        { x + lenX + widX, y + lenY + widY, 0.5, offset + self.len, 0, color },
        { x + lenX - widX, y + lenY - widY, 0.5, offset + self.len, texwid, color },
        { x - widX, y - widY, 0.5, offset, texwid, color })

    -- 装饰星星
    local scale = 0.7 + 0.4 * sin(self.timer * 45 + self.idx * 90)
    Render(img .. 'laser-star', x, y, self.timer * 5, scale * self.valid)

    -- 击中特效
    scale = 0.9 - 0.1 * sin(self.timer * 72)
    RenderAnimation(
        img .. 'laser-eff',
        self.ani,
        x + self.len * cos(self.rot),
        y + self.len * sin(self.rot),
        0,
        scale * self.eff_scale * self.valid)
end

---由 坐标(x,y) 朝向(rot) 碰撞大小(a,b) 检测是否碰撞, 然后触发colli回调
---但是触发colli回调 不等于 造成伤害
---这里是触发colli回调时, 只标记敌机对象, 实际造成伤害在下一轮frame回调时进行
function laser:colli(other)
    if not (other.group == GROUP_ENEMY or other.group == GROUP_NONTJT) then return end
    local len = Dist(other.x, other.y, self.rx, self.ry) - other.a
    if self.tmplen > len then
        self.tmplen = max(0, len)
        self.target = other
        self.is_hit = true
    end
end

---渲染是渲染, 判定是判定, 伤害是伤害, 可以没有关联的
function laser:frame()
    local player = self.player
    local sp = player.spinfo
    local idx = self.idx

    -- 有效性: 子机有效&按下射击&高速, 都是0~1平滑过渡的属性
    self.valid = sp.valid[idx] * player.fire * (1 - player.lh)

    -- 判定
    self.rot = sp.rot[idx]
    self.x = self.rx + self.maxlen / 2 * cos(self.rot)
    self.y = self.ry + self.maxlen / 2 * sin(self.rot)

    -- 渲染
    self.rx, self.ry = sp.x[idx], sp.y[idx]
    self.len = self.tmplen
    self.offset = self.offset - 12

    -- 伤害
    -- 修复使用bomb时激光仍有伤害的bug
    local dmg_factor = (player.nextshoot <= 4) and 1 or 0
    self.dmg = self.DMG * self.valid * dmg_factor
    -- 修复激光没有伤害时仍有判定显示的特性
    self.colli = self.dmg > 0

    -- 击中特效大小
    if self.is_hit then
        self.eff_scale = self.eff_scale + 0.2
    else
        self.eff_scale = self.eff_scale - 0.2
    end
    -- if self.eff_scale < 0 then self.eff_scale = 0 end
    -- if self.eff_scale > 1 then self.eff_scale = 1 end
    self.eff_scale = max(0, min(1, self.eff_scale))

    -- 造成伤害
    if IsValid(self.target) and self.target.colli then
        self.target.class.colli(self.target, self)
    end

    -- 恢复临时属性
    self.is_hit = false
    self.target = nil
    self.tmplen = self.maxlen
end

---魔理沙自机翻新
---适用于 LuaSTG aex+ 0.8.22 版本

lstg.plugin.RegisterEvent('afterTHlib', 'Marisa 2P', 98, function()
    for _, filename in ipairs {
        'main', 'resources', 'supports', 'shoot', 'bomb', 'laser'
    } do
        Include('marisa-player/' .. filename .. '.lua')
    end
end)

---魔理沙自机翻新
---适用于 LuaSTG aex+ 0.8.20 及以上版本

lstg.plugin.RegisterEvent('afterTHlib', 'Marisa 2P', 98, function()
    require 'marisa.main'
    require 'marisa.resource'
    require 'marisa.support'
    require 'marisa.shoot'
    require 'marisa.laser'
    require 'marisa.bomb'
end)

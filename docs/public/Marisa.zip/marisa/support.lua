---虽然可以用默认的子机系统, 但是演示一下手写子机系统

local lib = require 'marisa.lib'

---子机系统初始化
table.insert(lib.init_events, function(self)
    ---@class Marisa2P.SpInfo
    self.spinfo = {
        -- 数组部分类似sp表, 每帧更新

        -- 类似slist表
        list = {
            {},
            {
                -- 高速x, 高速y, 高速朝向 (给激光用的),
                -- 低速x, 低速y, 低速朝向 (低速没有激光所以全设为90)
                { 0, 32, 90, 0, 29, 90 },
            },
            {
                { -30, 10, 95, -8, 23, 90 },
                { 30,  10, 85, 8,  23, 90 },
            },
            {
                { -30, 0,  95, -10, 24, 90 },
                { 0,   32, 90, 0,   32, 90 },
                { 30,  0,  85, 10,  24, 90 },
            },
            {
                { -30, 10, 95, -15,  20, 90 },
                { -12, 32, 90, -7.5, 29, 90 },
                { 12,  32, 90, 7.5,  29, 90 },
                { 30,  10, 85, 15,   20, 90 },
            },
        },
        -- 子机有效性 (0~1)
        valid = { 0, 0, 0, 0 },
    }
end)

---子机系统更新
table.insert(lib.frame_events, function(self)
    ---@type Marisa2P.SpInfo
    local sp = self.spinfo
    if not self.time_stop then
        local s = int(self.support) + 1
        local t = self.support - int(self.support)
        for i = 1, 4 do
            local valid0 = sp.list[s][i]
            -- 考虑到4P情况, 需要先判断sp.list[s+1]是否存在
            local valid1 = sp.list[s + 1] and sp.list[s + 1][i]

            if valid0 and valid1 then
                sp[i] = MixTable(t,
                    MixTable(self.lh, sp.list[s][i]),
                    MixTable(self.lh, sp.list[s + 1][i]))
                sp.valid[i] = 1
            elseif valid0 and not valid1 then
                -- 由于子机随火力增加不会减少, 该分支实际上不会触发
                sp[i] = MixTable(self.lh, sp.list[s][i])
                sp.valid[i] = 1 - t
            elseif not valid0 and valid1 then
                sp[i] = MixTable(self.lh, sp.list[s + 1][i])
                sp.valid[i] = t
            else
                -- 此时sp[i]可能不存在, 使用时需要判断
                sp.valid[i] = 0
            end
        end
    end
end)

---子机渲染
table.insert(lib.render_events, function(self)
    ---@type Marisa2P.SpInfo
    local sp = self.spinfo
    for i = 1, 4 do
        if sp[i] then
            Render(lib.res .. 'support1', self.supportx + sp[i][1], self.supporty + sp[i][2], 0, sp.valid[i], 1)
        end
    end
end)

---资源加载

local lib = require 'marisa.lib'

local function load_img(name)
    LoadImageFromFile(lib.res .. name, lib.assets .. name .. '.png', false)
end

local function load_img_group(name, cols, rows)
    LoadImageGroupFromFile(lib.res .. name, lib.assets .. name .. '.png', false, cols, rows)
end

local function load_ani(name, cols, rows, interval)
    LoadAniFromFile(lib.res .. name, lib.assets .. name .. '.png', false, cols, rows, interval)
end

local function set_img_state(name, blend, a, r, g, b)
    SetImageState(lib.res .. name, blend, Color(a or 255, r or 255, g or 255, b or 255))
end

local function set_ani_state(name, blend, a, r, g, b)
    SetAnimationState(lib.res .. name, blend, Color(
        a or 255, r or 255, g or 255, b or 255))
end

---资源加载事件
table.insert(lib.init_events, function()
    -- 自机 & 子机
    load_img_group('walk-image', 8, 3)
    load_img_group('support', 13, 1)

    -- 主炮子弹
    load_img('bullet')
    set_img_state('bullet', '', 128)
    load_ani('bullet-eff', 4, 1, 4)
    set_ani_state('bullet-eff', '', 128)

    -- 导弹
    load_img('missile')
    set_img_state('missile', '', 240)
    load_ani('missile-eff', 4, 1, 2)
    set_ani_state('missile-eff', 'mul+add', 128)

    -- 激光
    LoadTexture(lib.res .. 'laser', lib.assets .. 'laser.png')
    SetTextureSamplerState(lib.res .. 'laser', 'linear+wrap') -- 更改纹理的采样方式, 简化激光渲染
    load_ani('laser-eff', 4, 1, 4)
    load_img('laser-star')
    set_img_state('laser-star', 'mul+add', 80)

    -- 魔炮
    load_img('spark')
    SetImageCenter(lib.res .. 'spark', 0, 64) -- 更改图片中心点, 简化魔炮渲染
    load_img('spark-wave')
    
    load_img('star')
end)

---@class Marisa2P.Lib
return {
    res = 'marisa-player:',           -- 资源名前缀
    assets = 'marisa/assets/', -- 资源所在文件夹
    marisa = Class(player_class),     -- 自机类
    init_events = {},                 -- 初始化执行的事件
    frame_events = {},                -- 每帧执行的事件
    render_events = {},               -- 渲染时执行的事件
}

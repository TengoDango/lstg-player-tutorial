---自机类的定义

local lib = require 'marisa.lib'

MarisaPlayer2 = lib.marisa
AddPlayerToPlayerList('Kirisame Marisa 2P', 'MarisaPlayer2', 'Marisa')

function lib.marisa:init()
    player_class.init(self)

    for _, event in ipairs(lib.init_events) do
        event(self)
    end

    self.hspeed, self.lspeed = 5, 2
    self.A, self.B = 1, 1
    self.imgs = {}
    for i = 1, 24 do
        self.imgs[i] = lib.res .. 'walk-image' .. i
    end
end

function lib.marisa:frame()
    player_class.frame(self)
    for _, event in ipairs(lib.frame_events) do
        event(self)
    end
end

function lib.marisa:render()
    player_class.render(self)
    for _, event in ipairs(lib.render_events) do
        event(self)
    end
end

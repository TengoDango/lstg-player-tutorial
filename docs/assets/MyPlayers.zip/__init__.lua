lstg.plugin.RegisterEvent("afterMod", "My Players", 100, function()
    Include("test-player/player.lua")
    Include("reimu-player/player.lua")
end)
